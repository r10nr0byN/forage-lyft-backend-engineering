from abc import ABC


class Tires(ABC):
    def needs_service(self):
        pass
